android_device_samsung_gavini
=============================

CyanogenMod 11 Device Tree for Samsung Galaxy Beam (GT-I8530)

Supported variants:
  - GT-I8530 (INTL)
